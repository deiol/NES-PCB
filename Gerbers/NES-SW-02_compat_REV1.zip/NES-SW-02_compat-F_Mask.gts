%TF.GenerationSoftware,KiCad,Pcbnew,9.0.8*%
%TF.CreationDate,2026-03-19T20:17:47-04:00*%
%TF.ProjectId,NES-SW-02_compat,4e45532d-5357-42d3-9032-5f636f6d7061,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.8) date 2026-03-19 20:17:47*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
